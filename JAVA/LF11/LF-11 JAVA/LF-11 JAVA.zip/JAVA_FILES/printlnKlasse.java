package tag01;

public class printlnKlasse { 
	public static void main(String[] myparams)  { 
	   String meintext = "Textteil - vgl."; 
	   System.out.print(meintext + " Ergänzung..");
	   System.out.println(meintext);  
	}
}
